﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'ka', {
	about: 'SCAYT-ის შესახებ',
	aboutTab: 'ინფორმაცია',
	addWord: 'სიტყვის დამატება',
	allCaps: 'დიდი ასოებით დაწერილი სიტყვების უგულებელყოფა',
	dic_create: 'შექმნა',
	dic_delete: 'წაშლა',
	dic_field_name: 'ლექსიკონის სახელი',
	dic_info: 'თავდაპირველად მომხმარებლის ლექსიკონი ინახება Cookie-ში. თუმცა Cookie შეზღუდულია ზომაში. როცა ლექსიკონის ზომა გაიზრდება საკმაოდ ის შეიძლება შევინახოთ ჩვენს სერვერზე. ჩვენს სერვერზე ლექსიკონს შესანახად უნდა მიუთითოთ მისი სახელი. თუ უკე გაქვთ ლექსიკონი, აკრიფეთ მისი სახელი და დააჭირეთ "დაბრუნების" ღილაკს.',
	dic_rename: 'გადარქმევა',
	dic_restore: 'დაბრუნება',
	dictionariesTab: 'ლექსიკონები',
	disable: 'SCAYT-ის გამორთვა',
	emptyDic: 'ლექსიკონის სიტყვა არ უნდა იყოს ცარიელი.',
	enable: 'SCAYT-ის ჩართვა',
	ignore: 'უგულებელყოფა',
	ignoreAll: 'ყველას უგულებელყოფა',
	ignoreDomainNames: 'დომენური სახელების უგულებელყოფა',
	langs: 'ენები',
	languagesTab: 'ენები',
	mixedCase: 'შერეული ასოებანი სიტყვების უგულებელყოფა',
	mixedWithDigits: 'ციფრებიანი სიტყვების უგულებელყოფა',
	moreSuggestions: 'მეტი შემოთავაზება',
	opera_title: 'არაა მხარდაჭერილი Opera-ს მიერ',
	options: 'პარამეტრები',
	optionsTab: 'პარამეტრები',
	title: 'მართლწერის შემოწმება კრეფისას',
	toggle: 'SCAYT-ის გადართვა',
	noSuggestions: 'No suggestion'
});
