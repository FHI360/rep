(function ($) {
    $("ul.jquerymenu li.closed span.closed").addClass("open").removeClass("closed");
    $("ul.jquerymenu li.closed").addClass("open").removeClass("closed");
})(jQuery);;
